import React, { Component } from "react";

class ViewRecord extends Component {
  state = {};

  render() {
    let data = JSON.parse(this.props.filename);
    return (
      <table>
        <tbody> {data} </tbody>
      </table>
    );
  }
}

export default ViewRecord;
